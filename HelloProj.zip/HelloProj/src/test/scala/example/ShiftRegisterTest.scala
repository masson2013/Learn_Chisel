package example

import chisel3._
import chisel3.util._
import chisel3.iotesters._
import scala.collection.mutable.Queue

class ShiftRegisterTest(c: EnableShiftRegister) extends PeekPokeTester(c) {

  poke(c.io.in, "b1010".U)
  step(1)
  poke(c.io.shift, true.B)
  println("Output: " + peek(c.io.out).toString)
  step(1)
  poke(c.io.shift, false.B)
  println("Output: " + peek(c.io.out).toString)
  step(1)
  poke(c.io.shift, true.B)
  println("Output: " + peek(c.io.out).toString)
  step(1)
  poke(c.io.shift, true.B)
  println("Output: " + peek(c.io.out).toString)
  step(1)
  poke(c.io.shift, true.B)
  println("Output: " + peek(c.io.out).toString)
  step(1)
  poke(c.io.shift, true.B)
  println("Output: " + peek(c.io.out).toString)

  Predef.printf("Place Holder\n")
}

object ShiftRegisterTester extends App {
    iotesters.Driver.execute(
    Array("--target-dir", "generated", "--generate-vcd-output", "on"), 
      () => new EnableShiftRegister()) {
    c => new ShiftRegisterTest(c)
  }
}
