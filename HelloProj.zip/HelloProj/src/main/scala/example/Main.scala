package example

import chisel3._

object ChiselExample extends App {
  chisel3.Driver.execute(args, () => new FullAdder)
  chisel3.Driver.execute(args, () => new EnableShiftRegister)
}
